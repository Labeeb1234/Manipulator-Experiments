from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch.conditions import IfCondition
import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch.actions import ExecuteProcess, TimerAction


def read_file(urdf_fp):
    try:
        with open(file=urdf_fp, mode='r') as file:
            return file.read()
    except EnvironmentError:
        return None


def generate_launch_description():
    share_dir = get_package_share_directory('dobot_description')
    xacro_file = os.path.join(share_dir, 'urdf', 'dobot_magician.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()


    rviz_config_fp = os.path.join(share_dir, 'rviz', 'view.rviz')

    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='whether to use simulation time or real time'
    )
    rviz_arg = DeclareLaunchArgument(
        'show_rviz',
        default_value='true',
        description='whether to show rviz for viz'
    )
    
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[
            {
            'robot_description': robot_urdf,
            'use_sim_time': LaunchConfiguration('use_sim_time')
            }
        ]
    )

    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher'
    )

    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzserver.launch.py'
            ])
        ]),
        launch_arguments={
            'pause': 'true'
        }.items()
    )

    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzclient.launch.py'
            ])
        ])
    )

    urdf_spawn_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'dobot_magician',
            '-topic', 'robot_description',
            '-x', '0.0', 
            '-y', '0.0', 
            '-z', '0.14',
            '-R', '0.0',
            '-P', '0.0',
            '-Y', '0.0'
        ],
        output='screen'
    )

    rviz_node = Node(
        condition=IfCondition(LaunchConfiguration('show_rviz')),
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_fp],
        output='screen'
    )

    load_joint_trajectory_controller = Node(
        package='controller_manager',
        executable='spawner',
        name='joint_trajectory_controller',
        arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager']
    )

    load_joint_state_broadcaster = Node(
        package='controller_manager',
        executable='spawner',
        name='joint_state_broadcaster',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager']
    )


    return LaunchDescription([
        use_sim_time_arg,
        rviz_arg,
        robot_state_publisher_node,
        #joint_state_publisher_node,
        gazebo_server,
        gazebo_client, 
        urdf_spawn_node,
        rviz_node,
        TimerAction(period=1.0,
            actions=[load_joint_trajectory_controller])
    ])