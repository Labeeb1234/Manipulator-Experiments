from launch_ros.actions import Node
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition, UnlessCondition
import xacro
import os
from ament_index_python.packages import get_package_share_directory


def read_file(urdf_fp):
    try:
        with open(file=urdf_fp, mode='r') as file:
            return file.read()
    except EnvironmentError:
        return None


def generate_launch_description():
    share_dir = get_package_share_directory('dobot_description')
    xacro_file = os.path.join(share_dir, 'urdf', 'dobot_magician.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()

    rviz_config_fp = os.path.join(share_dir, 'rviz', 'view.rviz')

    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='whether to use simulation time or not'
    )

    gui_arg = DeclareLaunchArgument(
        name='gui',
        default_value='True'
    )

    rviz_arg = DeclareLaunchArgument(
        'show_rviz',
        default_value='true',
        description='whether to show rviz for viz'
    )

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{
            'robot_description': robot_urdf,
            'use_sim_time': LaunchConfiguration('use_sim_time')   
        }]
    )

    joint_state_publisher_node = Node(
        condition=UnlessCondition(LaunchConfiguration('gui')),
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        # parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time') }]
    )

    joint_state_publisher_gui_node = Node(
        condition=IfCondition(LaunchConfiguration('gui')),
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        # parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time') }]
    )

    rviz_node = Node(
        condition=IfCondition(LaunchConfiguration('show_rviz')),
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_fp],
        output='screen'
    )


    ld = LaunchDescription()
    ld.add_action(use_sim_time_arg)
    ld.add_action(gui_arg)
    ld.add_action(rviz_arg)
    ld.add_action(robot_state_publisher_node)
    ld.add_action(joint_state_publisher_node)
    ld.add_action(joint_state_publisher_gui_node)
    ld.add_action(rviz_node)
    
    return ld
        

